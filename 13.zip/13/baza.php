<?php

$baza = mysqli_connect("localhost", "root", "", "baza");

if(mysqli_connect_error())
{
    die ("Desila se greška prilikom konektovanja na bazu podataka.");
}



if(!isset($_POST['ime_prezime']) || empty($_POST['ime_prezime']) )
{
 die("Niste uneli ime.");
}

if(!isset($_POST['email']) || empty($_POST['email']) )
{
 die("Niste uneli e-mail.");
}

if(!isset($_POST['lozinka']) || empty($_POST['lozinka']) )
{
 die("Niste uneli lozinku.");
}

if(!isset($_POST['datum_rodjenja']) || empty($_POST['datum_rodjenja']) )
{
 die("Niste uneli datum rodjenja.");
}



$imePrezime = $_POST['ime_prezime'];
$email = $_POST['email'];
$lozinka = $_POST['lozinka'];
$datum_rodjenja = $_POST['datum_rodjenja'];


$baza->query("INSERT INTO korisnici (ime_prezime, email, lozinka, datum_rodjenja) VALUES ('$imePrezime', '$email', '$lozinka', '$datum_rodjenja')");











?>